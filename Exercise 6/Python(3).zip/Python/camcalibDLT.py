import numpy as np


def camcalibDLT(x_world, x_im):
    """
    :param x_world: World coordinatesm with shape (point_id, coordinates)
    :param x_im: Image coordinates with shape (point_id, coordinates)
    :return P: Camera projection matrix with shape (3,4)
    """

    # Create the matrix A 
    ##-your-code-starts-here-##
    A = np.zeros((2 * x_world.shape[0], 12))
    for i in range(x_world.shape[0]):
        X, Y, Z, W = x_world[i]
        u, v, w = x_im[i]
        A[2*i] = [-X, -Y, -Z, -W, 0, 0, 0, 0, u*X, u*Y, u*Z, u*W]
        A[2*i + 1] = [0, 0, 0, 0, -X, -Y, -Z, -W, v*X, v*Y, v*Z, v*W]
    ##-your-code-ends-here-##
    
    # Perform homogeneous least squares fitting.
    # The best solution is given by the eigenvector of
    # A.T*A with the smallest eigenvalue.
    ##-your-code-starts-here-##
    _, _, V = np.linalg.svd(A)
    ##-your-code-ends-here-##
    
    # Reshape the eigenvector into a projection matrix P
    P = np.reshape(V[-1], (3, 4))  # here ev is the eigenvector from above
    
    return P
